const data =[
    {
      "Trade date": "15/6/2018 ",
      "Commodity": "gold",
      "Side": "sell",
      "Qty(MT)": "5000",
      "price(MT)": "600000",
      "Counterparty": "BALCO",
      "Location": "bangalore",
    },
    {
        "Trade date": "15/6/2018 ",
        "Commodity": "gold",
        "Side": "sell",
        "Qty(MT)": "5001",
        "price(MT)": "600001",
        "Counterparty": "BALCO",
        "Location": "bangalore",
      },
      {
        "Trade date": "15/6/2018 ",
        "Commodity": "gold",
        "Side": "buy",
        "Qty(MT)": "5000",
        "price(MT)": "600000",
        "Counterparty": "BALCO",
        "Location": "bangalore",
      },
      {
        "Trade date": "15/6/2016",
        "Commodity": "gold",
        "Side": "sell",
        "Qty(MT)": "5000",
        "price(MT)": "600000",
        "Counterparty": "BALCO",
        "Location": "bangalore",
      },
      {
        "Trade date": "15/6/2017 ",
        "Commodity": "copper",
        "Side": "sell",
        "Qty(MT)": "5000",
        "price(MT)": "600000",
        "Counterparty": "BALCO",
        "Location": "bangalore",
      }
    

];


export default posts;