import React, { Component } from 'react';

import TradeComponent from './trade.component';
export default class TradeTable extends Component { 

  constructor() {
    super();
    this.state = {
      tradedata: [

        {
          "Tradedate": "15/6/2018 ",
          "Commodity": "gold",
          "Side": "sell",
          "Qty": "5000",
          "price": "600000",
          "Counterparty": "BALCO",
          "Location": "bangalore",
        },
        {
            "Tradedate": "15/6/2018 ",
            "Commodity": "gold",
            "Side": "sell",
            "Qty": "5001",
            "price": "600001",
            "Counterparty": "BALCO",
            "Location": "bangalore",
          },
          {
            "Tradedate": "15/6/2018 ",
            "Commodity": "gold",
            "Side": "buy",
            "Qty": "5000",
            "price": "600000",
            "Counterparty": "BALCO",
            "Location": "bangalore",
          },
          {
            "Tradedate": "15/6/2016",
            "Commodity": "gold",
            "Side": "sell",
            "Qty": "5000",
            "price": "600000",
            "Counterparty": "BALCO",
            "Location": "bangalore",
          },
          {
            "Tradedate": "15/6/2017 ",
            "Commodity": "copper",
            "Side": "sell",
            "Qty": "5000",
            "price": "600000",
            "Counterparty": "BALCO",
            "Location": "bangalore", 

        }
      ]

    };

  }
    // componentDidMount() {
    //     fetch('url for fetching trade table')
    //     .then(res => res.json())
    //     .then(data=> {
    //         this.setState({tradedata: data});
    //     });
        


    // }

 

  render() {

 

    console.log(

      this.state.tradedata);


 

    return (

 

      <div class="container">

        <table class="table table-striped">

          <thead>

            <tr>

              <th>Trade Date</th>

              <th>Commodity</th>

              <th>Side</th>

              <th>Qty</th>

              <th>Price</th>

              <th>Counterparty</th>

              <th>Location</th>

            </tr>

          </thead>

          <tbody>

 

            {

              this.state.tradedata.map((p, i) => {

                return <TradeComponent
                  postData={p}
                  index={i}
                  {...this.props}
                />

              }

              )

            }

          </tbody>

        </table>

      </div>

    )





  }

}