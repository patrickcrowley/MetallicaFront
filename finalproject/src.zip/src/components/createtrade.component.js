import React, { Component }
    from 'react';



export default class CreateTradeComponent extends Component {
    constructor() {
        super();

        var today = new Date(),
            date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();

        this.state = {
            date: date,
            Side:''
           

        };
        this.handleChange = this.handleChange.bind(this);     

        this.commodity = React.createRef();
       this.CounterParty = React.createRef();
        this.Price = React.createRef();
        this.Quantity = React.createRef();
        this.Location = React.createRef();
        this.Side=React.createRef();             

        console.log(this.state.Side);

    }
    handleChange(event) {
        console.log(event.target.value);
        this.setState({
          Side: event.target.value
        });
      }
      saveTrade(){
          console.log(this.commodity.current.value);
          console.log(this.CounterParty.current.value);
          console.log(this.Price.current.value);
          console.log(this.Quantity.current.value);
          console.log(this.Location.current.value);
          console.log(this.state.Side);
          
      }
      cancelTrade(){
          console.log("inside cancel trade");
      }

    

    render() {

        return (

            <form className="postStyle">
                Trade&nbsp;Date&nbsp;&nbsp;&nbsp;&nbsp;: <input ref={this.tradedate} value={this.state.date} /> <br />
                Commodity&nbsp;&nbsp;&nbsp;: <input ref={this.commodity} type="text" /> <br />
                Side&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <label><input  type="radio" name="Buy" value ="Buy" checked={this.state.Side === "Buy"} onChange={this.handleChange}  />Buy</label><label> <input  type="radio" name="Sell" value="Sell" checked={this.state.Side === "Sell"} onChange={this.handleChange} />Sell</label> <br />
                CounterParty : <input ref ={this.CounterParty} type="text" /> <br />
                Price&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <input ref={this.Price} type="text" /> <br />
                Quantity&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <input ref={this.Quantity} type="text" /> <br />
                Location&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <input ref={this.Location} type="text" /> <br /><br/>
                <input type="button" value="Save" onClick={this.saveTrade.bind(this)}/>
                 <input type="button" value="Cancel" onClick={this.cancelTrade.bind(this)} />
            </form>
            
 
 

            

        );

    }

}




