import React ,{Component} from 'react';

export default class TradeComponent extends Component{
render(){
return( 
    

<tr >

<td scope="col"> {this.props.postData.Tradedate}</td>
<td>{this.props.postData.Commodity}</td>
<td>{this.props.postData.Side}</td>
<td>{this.props.postData.Qty}</td>
<td>{this.props.postData.price}</td>
<td>{this.props.postData.Counterparty}</td>
<td>{this.props.postData.Location}</td>
</tr> 
)

}
}  